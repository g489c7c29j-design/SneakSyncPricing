import { type Comparable, type Product, type Rules } from "@shared/schema";

export interface PriceCalculation {
  suggestedPrice: number;
  rawMedian: number;
  delta: number;
  deltaPct: number;
  shouldAutoUpdate: boolean;
  reason: string;
  sourceCount: number;
  sources: { source: string; count: number }[];
}

function trimmedMedian(values: number[], trimPct: number = 0.2): number {
  if (values.length === 0) return 0;
  if (values.length === 1) return values[0];

  const sorted = [...values].sort((a, b) => a - b);
  const trimCount = Math.floor(sorted.length * trimPct);
  const trimmed = sorted.slice(trimCount, sorted.length - trimCount);

  if (trimmed.length === 0) return sorted[Math.floor(sorted.length / 2)];

  const mid = Math.floor(trimmed.length / 2);
  if (trimmed.length % 2 === 0) {
    return (trimmed[mid - 1] + trimmed[mid]) / 2;
  }
  return trimmed[mid];
}

function applyRounding(price: number, mode: string): number {
  if (mode === ".99") {
    return Math.floor(price) + 0.99;
  } else if (mode === ".95") {
    return Math.floor(price) + 0.95;
  } else if (mode === ".00") {
    return Math.round(price);
  }
  return price;
}

export function calculatePrice(
  product: Product,
  comparables: Comparable[],
  rules: Rules
): PriceCalculation {
  if (comparables.length === 0) {
    return {
      suggestedPrice: product.currentPrice,
      rawMedian: 0,
      delta: 0,
      deltaPct: 0,
      shouldAutoUpdate: false,
      reason: "No comparable data available",
      sourceCount: 0,
      sources: [],
    };
  }

  const minutesSinceLastUpdate = (Date.now() - product.lastUpdated.getTime()) / (1000 * 60);
  const cooldownActive = minutesSinceLastUpdate < rules.cooldownMinutes;

  // CONDITION-AWARE FILTERING
  // Filter comparables by condition type and score (±1 for USED items)
  let conditionFilteredComps = comparables;
  
  if (product.conditionType === "NEW") {
    // For NEW items, only match with NEW comparables
    conditionFilteredComps = comparables.filter(c => c.conditionType === "NEW");
  } else if (product.conditionType === "USED" && product.conditionScore !== null) {
    // For USED items, only match with USED comparables within ±1 condition score
    const targetScore = product.conditionScore;
    conditionFilteredComps = comparables.filter(c => {
      if (c.conditionType !== "USED") return false;
      if (c.conditionScore === null) return false;
      return Math.abs(c.conditionScore - targetScore) <= 1;
    });
  }

  // Separate sold comps from active listings (after condition filtering)
  const soldComps = conditionFilteredComps.filter(c => c.listingType === "sold");
  const activeListings = conditionFilteredComps.filter(c => c.listingType === "active");

  // Prefer sold data for used/pre-owned shoes
  // Use active listings only if no sold data exists
  let pricesForCalculation: Comparable[];
  let usingActiveFallback = false;

  if (product.conditionType === "NEW") {
    // For new shoes: prefer sold data, fall back to active listings
    pricesForCalculation = soldComps.length > 0 ? soldComps : activeListings;
    usingActiveFallback = soldComps.length === 0 && activeListings.length > 0;
  } else {
    // For used/pre-owned: REQUIRE sold data from GOAT/marketplace
    // Do not use StockX or active listings
    pricesForCalculation = soldComps;
    usingActiveFallback = false;
  }

  const prices = pricesForCalculation
    .map((c) => c.price - c.fees - c.shipping)
    .filter((p) => Number.isFinite(p) && p >= 0);
  
  if (prices.length === 0) {
    let reason = "No valid comparable data after filtering";
    
    if (product.conditionType === "USED") {
      if (product.conditionScore !== null) {
        reason = `No sold USED comparables found with condition score ${product.conditionScore}±1. Please add sold listings from GOAT or marketplace with similar condition.`;
      } else {
        reason = "No sold comparable data for used shoes. Please add sold listings from GOAT or marketplace.";
      }
    } else if (product.conditionType === "NEW") {
      reason = conditionFilteredComps.length === 0
        ? "No NEW comparables found. All available comparables are USED."
        : "No valid NEW comparable data after filtering";
    }
    
    return {
      suggestedPrice: product.currentPrice,
      rawMedian: 0,
      delta: 0,
      deltaPct: 0,
      shouldAutoUpdate: false,
      reason,
      sourceCount: 0,
      sources: [],
    };
  }
  
  const rawMedian = trimmedMedian(prices);

  // Only apply discount if using active listings as fallback (no sold data)
  // This helps estimate value when real sold data is unavailable
  const conditionMultiplier = usingActiveFallback
    ? (product.condition === "pre-owned" ? 0.70 : product.condition === "used" ? 0.85 : 1.0)
    : 1.0; // No discount when using sold data - it's already market reality
  
  const conditionAdjustedMedian = rawMedian * conditionMultiplier;

  const minPrice = product.costBasis * (1 + rules.minMarginPct / 100);
  const marketBaseline = Math.max(conditionAdjustedMedian, minPrice);
  const rounded = applyRounding(marketBaseline, rules.roundingMode);
  const suggestedPrice = Math.max(rounded, minPrice);

  const delta = suggestedPrice - product.currentPrice;
  const deltaPct = product.currentPrice > 0 ? (delta / product.currentPrice) * 100 : 0;

  const sourceCounts = comparables.reduce((acc, c) => {
    acc[c.source] = (acc[c.source] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sources = Object.entries(sourceCounts).map(([source, count]) => ({
    source,
    count,
  }));

  let shouldAutoUpdate = false;
  let reason = "";

  if (product.isProtected) {
    reason = "Product is protected from auto-updates";
  } else if (!rules.autoUpdate) {
    reason = "Auto-update is disabled";
  } else if (cooldownActive) {
    const minutesRemaining = Math.ceil(rules.cooldownMinutes - minutesSinceLastUpdate);
    reason = `Cooldown active: ${minutesRemaining} minutes remaining`;
  } else if (Math.abs(deltaPct) > rules.dailyCapPct) {
    reason = `Delta ${deltaPct.toFixed(1)}% exceeds daily cap of ${rules.dailyCapPct}%`;
  } else if (deltaPct > 0 && deltaPct <= rules.toleranceHighPct) {
    shouldAutoUpdate = true;
    reason = `Price increase ${deltaPct.toFixed(1)}% within tolerance`;
  } else if (deltaPct < 0 && Math.abs(deltaPct) <= rules.toleranceLowPct) {
    shouldAutoUpdate = true;
    reason = `Price decrease ${deltaPct.toFixed(1)}% within tolerance`;
  } else if (deltaPct > rules.toleranceHighPct) {
    reason = `Price increase ${deltaPct.toFixed(1)}% exceeds tolerance ${rules.toleranceHighPct}%`;
  } else if (Math.abs(deltaPct) > rules.toleranceLowPct) {
    reason = `Price decrease ${Math.abs(deltaPct).toFixed(1)}% exceeds tolerance ${rules.toleranceLowPct}%`;
  } else {
    reason = "No price change needed";
  }

  return {
    suggestedPrice,
    rawMedian,
    delta,
    deltaPct,
    shouldAutoUpdate,
    reason,
    sourceCount: comparables.length,
    sources,
  };
}

export function parseCSV(csvContent: string): Array<{
  source: string;
  sku: string;
  styleCode: string;
  size: string | null;
  listingType: string;
  condition: string | null;
  conditionType?: string;
  conditionScore?: number;
  price: number;
  currency: string;
  fees: number;
  shipping: number;
  saleDate: string;
  productUrl: string | null;
}> {
  const lines = csvContent.trim().split("\n");
  if (lines.length < 2) {
    throw new Error("CSV file is empty or missing header");
  }

  const header = lines[0].toLowerCase().split(",").map((h) => h.trim());
  const rows = lines.slice(1);

  const results: Array<{
    source: string;
    sku: string;
    styleCode: string;
    size: string | null;
    listingType: string;
    condition: string | null;
    conditionType?: string;
    conditionScore?: number;
    price: number;
    currency: string;
    fees: number;
    shipping: number;
    saleDate: string;
    productUrl: string | null;
  }> = [];

  for (const row of rows) {
    if (!row.trim()) continue;

    const values = row.split(",").map((v) => v.trim());
    const obj: any = {};

    header.forEach((key, idx) => {
      obj[key] = values[idx] || "";
    });

    // Parse condition fields
    const condition = obj.condition || null;
    const conditionTypeStr = obj.condition_type || obj.conditiontype;
    const conditionScoreStr = obj.condition_score || obj.conditionscore;

    // If conditionType/Score provided in CSV, use them; otherwise derive from condition string
    let conditionType: string | undefined = conditionTypeStr;
    let conditionScore: number | undefined = conditionScoreStr ? parseInt(conditionScoreStr, 10) : undefined;

    results.push({
      source: obj.source || "csv",
      sku: obj.sku || "",
      styleCode: obj.style_code || obj.stylecode || obj.sku || "",
      size: obj.size || null,
      listingType: obj.listing_type || obj.listingtype || obj.type || "sold", // Default to sold for CSV imports
      condition,
      conditionType,
      conditionScore,
      price: parseFloat(obj.price) || 0,
      currency: obj.currency || "USD",
      fees: parseFloat(obj.fees) || 0,
      shipping: parseFloat(obj.shipping) || 0,
      saleDate: obj.date || obj.sale_date || obj.saledate || "",
      productUrl: obj.product_url || obj.producturl || obj.url || null,
    });
  }

  return results;
}

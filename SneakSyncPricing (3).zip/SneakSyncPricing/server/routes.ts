import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { calculatePrice, parseCSV } from "./pricing-engine";
import { syncService } from "./sync-service";
import {
  insertProductSchema,
  insertComparableSchema,
  insertRulesSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/rules", async (req, res) => {
    try {
      const rules = await storage.getRules();
      res.json({ ok: true, rules });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/rules", async (req, res) => {
    try {
      const validated = insertRulesSchema.partial().parse(req.body);
      const rules = await storage.updateRules(validated);
      res.json({ ok: true, rules });
    } catch (error: any) {
      res.status(400).json({ ok: false, error: error.message });
    }
  });

  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const rules = await storage.getRules();

      const productsWithSuggestions = await Promise.all(
        products.map(async (product) => {
          const comparables = await storage.getComparablesBySku(product.sku);
          const calculation = calculatePrice(product, comparables, rules);

          return {
            id: product.id,
            sku: product.sku,
            productName: product.name,
            condition: product.condition as "new" | "used" | "pre-owned",
            currentPrice: product.currentPrice,
            suggestedPrice: calculation.suggestedPrice,
            delta: calculation.deltaPct,
            status: product.isProtected
              ? "protected"
              : calculation.shouldAutoUpdate
              ? "auto-updated"
              : Math.abs(calculation.deltaPct) < 0.1
              ? "manual"
              : "pending",
            sources: calculation.sources.map((s) => ({
              source: s.source as "ebay" | "stockx" | "goat" | "csv",
              count: s.count,
            })),
            thumbnail: product.imageUrl || undefined,
            compData: comparables.slice(0, 6).map((c) => ({
              source: `${c.source.charAt(0).toUpperCase()}${c.source.slice(1)}`,
              price: c.price - c.fees - c.shipping,
              date: c.saleDate,
              size: c.size,
              productUrl: c.productUrl,
            })),
            // Add full product details for editing
            styleCode: product.styleCode,
            size: product.size,
            costBasis: product.costBasis,
            conditionType: product.conditionType,
            conditionScore: product.conditionScore,
            conditionNotes: product.conditionNotes,
            imageUrl: product.imageUrl,
            isProtected: product.isProtected,
          };
        })
      );

      res.json({ ok: true, products: productsWithSuggestions });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.get("/api/products/:sku", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.sku);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }
      res.json({ ok: true, product });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validated = insertProductSchema.parse(req.body);
      // Auto-extract size from product name if not provided
      if (!validated.size && validated.name) {
        const { extractSize } = await import("./storage");
        validated.size = extractSize(validated.name);
      }
      // Auto-extract condition from product name if not provided
      if (!validated.condition && validated.name) {
        const { extractCondition } = await import("./storage");
        validated.condition = extractCondition(validated.name);
      }
      const product = await storage.createProduct(validated);
      res.json({ ok: true, product });
    } catch (error: any) {
      res.status(400).json({ ok: false, error: error.message });
    }
  });

  app.patch("/api/products/:sku", async (req, res) => {
    try {
      const validated = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(req.params.sku, validated);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }
      res.json({ ok: true, product });
    } catch (error: any) {
      res.status(400).json({ ok: false, error: error.message });
    }
  });

  app.patch("/api/products/:sku/price", async (req, res) => {
    try {
      const { newPrice } = req.body;
      if (typeof newPrice !== "number") {
        return res.status(400).json({ ok: false, error: "newPrice must be a number" });
      }

      const product = await storage.getProduct(req.params.sku);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }

      const updated = await storage.updateProductPrice(req.params.sku, newPrice);

      await storage.createAuditLog({
        action: "manual",
        sku: product.sku,
        productName: product.name,
        oldPrice: product.currentPrice,
        newPrice,
        delta: ((newPrice - product.currentPrice) / product.currentPrice) * 100,
        user: "admin",
      });

      res.json({ ok: true, product: updated });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.patch("/api/products/:sku/protection", async (req, res) => {
    try {
      const { isProtected } = req.body;
      if (typeof isProtected !== "boolean") {
        return res.status(400).json({ ok: false, error: "isProtected must be a boolean" });
      }

      const product = await storage.setProductProtection(req.params.sku, isProtected);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }

      res.json({ ok: true, product });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/import/csv", async (req, res) => {
    try {
      const { csvContent } = req.body;
      if (!csvContent) {
        return res.status(400).json({ ok: false, error: "csvContent is required" });
      }

      const parsed = parseCSV(csvContent);
      const comparables = await storage.createComparables(parsed);

      res.json({ ok: true, imported: comparables.length, comparables });
    } catch (error: any) {
      res.status(400).json({ ok: false, error: error.message });
    }
  });

  app.get("/api/approvals", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const rules = await storage.getRules();

      const pending = [];
      for (const product of products) {
        if (product.isProtected) continue;

        const comparables = await storage.getComparablesBySku(product.sku);
        const calculation = calculatePrice(product, comparables, rules);

        if (!calculation.shouldAutoUpdate && Math.abs(calculation.deltaPct) >= 0.1) {
          pending.push({
            id: product.id,
            sku: product.sku,
            productName: product.name,
            currentPrice: product.currentPrice,
            suggestedPrice: calculation.suggestedPrice,
            delta: calculation.deltaPct,
            status: "pending" as const,
            sources: calculation.sources.map((s) => ({
              source: s.source as "ebay" | "stockx" | "goat" | "csv",
              count: s.count,
            })),
            compData: comparables.slice(0, 6).map((c) => ({
              source: `${c.source.charAt(0).toUpperCase()}${c.source.slice(1)}`,
              price: c.price - c.fees - c.shipping,
              date: c.saleDate,
              size: c.size,
              productUrl: c.productUrl,
            })),
          });
        }
      }

      res.json({ ok: true, approvals: pending });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/approvals/:sku/approve", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.sku);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }

      const comparables = await storage.getComparablesBySku(product.sku);
      const rules = await storage.getRules();
      const calculation = calculatePrice(product, comparables, rules);

      const updated = await storage.updateProductPrice(
        product.sku,
        calculation.suggestedPrice
      );

      await storage.createAuditLog({
        action: "approved",
        sku: product.sku,
        productName: product.name,
        oldPrice: product.currentPrice,
        newPrice: calculation.suggestedPrice,
        delta: calculation.deltaPct,
        user: "admin",
      });

      res.json({ ok: true, product: updated });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/approvals/:sku/reject", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.sku);
      if (!product) {
        return res.status(404).json({ ok: false, error: "Product not found" });
      }

      await storage.createAuditLog({
        action: "rejected",
        sku: product.sku,
        productName: product.name,
        oldPrice: product.currentPrice,
        newPrice: product.currentPrice,
        delta: 0,
        user: "admin",
      });

      res.json({ ok: true });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/compute-prices", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const rules = await storage.getRules();
      let autoUpdated = 0;

      for (const product of products) {
        const comparables = await storage.getComparablesBySku(product.sku);
        const calculation = calculatePrice(product, comparables, rules);

        if (calculation.shouldAutoUpdate && Math.abs(calculation.deltaPct) >= 0.1) {
          await storage.updateProductPrice(product.sku, calculation.suggestedPrice);

          await storage.createAuditLog({
            action: "auto_update",
            sku: product.sku,
            productName: product.name,
            oldPrice: product.currentPrice,
            newPrice: calculation.suggestedPrice,
            delta: calculation.deltaPct,
            user: null,
          });

          autoUpdated++;
        }
      }

      res.json({ ok: true, autoUpdated });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.get("/api/audit-log", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const logs = await storage.getAuditLog(limit);

      const formatted = logs.map((log) => ({
        id: log.id,
        timestamp: log.timestamp.toISOString().replace("T", " ").substring(0, 19),
        action: log.action as "auto_update" | "approved" | "rejected" | "manual",
        sku: log.sku,
        productName: log.productName,
        oldPrice: log.oldPrice,
        newPrice: log.newPrice,
        delta: log.delta,
        user: log.user,
      }));

      res.json({ ok: true, logs: formatted });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      const rules = await storage.getRules();
      const logs = await storage.getAuditLog(1000);

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const autoUpdatesToday = logs.filter(
        (log) => log.action === "auto_update" && log.timestamp >= today
      ).length;

      let pendingCount = 0;
      let totalDelta = 0;
      let marginProtectedCount = 0;

      for (const product of products) {
        const comparables = await storage.getComparablesBySku(product.sku);
        const calculation = calculatePrice(product, comparables, rules);

        if (!product.isProtected && !calculation.shouldAutoUpdate && Math.abs(calculation.deltaPct) >= 0.1) {
          pendingCount++;
        }

        totalDelta += Math.abs(calculation.deltaPct);

        if (calculation.suggestedPrice >= product.costBasis * (1 + rules.minMarginPct / 100)) {
          marginProtectedCount++;
        }
      }

      const avgDelta = products.length > 0 ? totalDelta / products.length : 0;
      const marginProtectedPct = products.length > 0 ? (marginProtectedCount / products.length) * 100 : 0;

      res.json({
        ok: true,
        stats: {
          autoUpdatesToday,
          pendingApprovals: pendingCount,
          avgDelta: avgDelta.toFixed(1),
          marginProtected: marginProtectedPct.toFixed(0),
        },
      });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/sync/product/:sku", async (req, res) => {
    try {
      const { sku } = req.params;
      const result = await syncService.syncProduct(sku);
      res.json({ ok: true, result });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/sync/all", async (req, res) => {
    try {
      const results = await syncService.syncAllProducts();
      const successCount = results.filter((r) => r.success).length;
      res.json({
        ok: true,
        results,
        summary: {
          total: results.length,
          success: successCount,
          failed: results.length - successCount,
        },
      });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

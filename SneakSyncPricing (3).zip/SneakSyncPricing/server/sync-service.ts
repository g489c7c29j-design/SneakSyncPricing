import { storage } from "./storage";
import { kicksdb } from "./kicksdb";

export interface SyncResult {
  sku: string;
  success: boolean;
  sourcesFound: number;
  error?: string;
}

export class SyncService {
  async syncProduct(sku: string): Promise<SyncResult> {
    try {
      const product = await storage.getProduct(sku);
      if (!product) {
        return {
          sku,
          success: false,
          sourcesFound: 0,
          error: "Product not found",
        };
      }

      await storage.updateProductSyncStatus(sku, "syncing");

      const { comparables, sources, imageUrl } = await kicksdb.fetchMarketPrices(
        product.styleCode,
        sku,
        product.size || "",
        product.condition as "new" | "used" | "pre-owned"
      );

      if (comparables.length > 0) {
        await storage.createComparables(comparables);
        
        if (imageUrl && !product.imageUrl) {
          await storage.updateProductImage(sku, imageUrl);
        }
        
        await storage.updateProductSyncStatus(sku, "success");
        return {
          sku,
          success: true,
          sourcesFound: sources.length,
        };
      } else {
        await storage.updateProductSyncStatus(sku, "no_data");
        return {
          sku,
          success: false,
          sourcesFound: 0,
          error: "No market data found",
        };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      await storage.updateProductSyncStatus(sku, "error");
      return {
        sku,
        success: false,
        sourcesFound: 0,
        error: errorMessage,
      };
    }
  }

  async syncAllProducts(): Promise<SyncResult[]> {
    const products = await storage.getAllProducts();
    const results: SyncResult[] = [];

    for (const product of products) {
      const result = await this.syncProduct(product.sku);
      results.push(result);
      
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    return results;
  }
}

export const syncService = new SyncService();

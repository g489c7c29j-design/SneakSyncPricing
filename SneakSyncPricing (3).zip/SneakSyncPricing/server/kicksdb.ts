import type { InsertComparable } from "@shared/schema";
import { mapConditionToTypeAndScore } from "./storage";

const KICKSDB_API_KEY = process.env.KICKSDB_API_KEY;
const KICKSDB_BASE_URL = "https://api.kicks.dev/v3";

interface KicksDBProduct {
  id: string | number;
  brand: string;
  title: string;
  sku: string;
  slug?: string;
  link?: string;
  image?: string;
  gallery?: string[];
  min_price?: number;
  max_price?: number;
  avg_price?: number;
  variants?: {
    size: string;
    price?: number;       // StockX uses 'price'
    lowest_ask?: number;  // GOAT uses 'lowest_ask'
    currency: string;
    barcode?: string;
  }[];
}

interface KicksDBResponse {
  data: KicksDBProduct | KicksDBProduct[];
  meta: any;
}

export interface MarketPrice {
  source: string;
  price: number;
  currency: string;
  saleDate: string;
}

export class KicksDBService {
  private apiKey: string;

  constructor(apiKey?: string) {
    if (!apiKey && !KICKSDB_API_KEY) {
      throw new Error("KicksDB API key not configured");
    }
    this.apiKey = apiKey || KICKSDB_API_KEY!;
  }

  private async request<T = any>(endpoint: string, params?: Record<string, string>): Promise<T> {
    const url = new URL(`${KICKSDB_BASE_URL}${endpoint}`);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    const response = await fetch(url.toString(), {
      headers: {
        "Authorization": `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`KicksDB API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async searchStockX(styleCode: string): Promise<KicksDBProduct | null> {
    try {
      const response = await this.request<KicksDBResponse>("/stockx/products", {
        query: styleCode,
        limit: "1",
      });

      if (Array.isArray(response.data) && response.data.length > 0) {
        return response.data[0];
      }
      return null;
    } catch (error) {
      console.error(`Error searching StockX for ${styleCode}:`, error);
      return null;
    }
  }

  async searchGOAT(styleCode: string): Promise<KicksDBProduct | null> {
    try {
      const searchResponse = await this.request<KicksDBResponse>("/goat/products", {
        query: styleCode,
        limit: "1",
      });

      if (Array.isArray(searchResponse.data) && searchResponse.data.length > 0) {
        const productId = searchResponse.data[0].id;
        
        // Fetch full product details by ID to get variants with pricing
        // GOAT search results don't include variants, but the product by ID endpoint does
        const fullProduct = await this.getProductById("goat", String(productId));
        
        if (fullProduct) {
          return fullProduct;
        }
      }
      
      return null;
    } catch (error) {
      console.error(`Error searching GOAT for ${styleCode}:`, error);
      return null;
    }
  }

  async getProductById(source: "stockx" | "goat", productId: string): Promise<KicksDBProduct | null> {
    try {
      const response = await this.request<KicksDBResponse>(`/${source}/products/${productId}`);
      
      if (response.data && !Array.isArray(response.data)) {
        return response.data;
      }
      return null;
    } catch (error) {
      console.error(`Error getting ${source} product ${productId}:`, error);
      return null;
    }
  }

  private normalizeSizeString(size: string): string {
    // Normalize size strings for comparison across StockX/GOAT/marketplace formats
    // Handles: "10.5", "10.5M", "10.5US", "10.5 (M)", "10.5Y", "10 ½", "10.5-GS", etc.
    
    let normalized = size
      .toUpperCase()
      .trim()
      // Remove parentheses and contents: "10.5 (M)" → "10.5"
      .replace(/\s*\([^)]*\)/g, '')
      // Replace unicode fractions with decimals: "10 ½" → "10.5"
      .replace(/½/g, '.5')
      .replace(/¼/g, '.25')
      .replace(/¾/g, '.75')
      .replace(/⅓/g, '.33')
      .replace(/⅔/g, '.67')
      // Remove all whitespace
      .replace(/\s+/g, '')
      // Remove common suffixes (order matters - do hyphenated first)
      .replace(/-GS$/i, '')    // Grade School
      .replace(/-PS$/i, '')    // Preschool
      .replace(/-TD$/i, '')    // Toddler
      .replace(/US$/i, '')
      .replace(/UK$/i, '')
      .replace(/EU$/i, '')
      .replace(/MEN$/i, '')
      .replace(/WOMEN$/i, '')
      .replace(/MENS$/i, '')
      .replace(/WOMENS$/i, '')
      // Handle Y (Youth) - but be careful not to remove Y from "11Y" → "11"
      .replace(/Y$/i, '')
      // Handle M/W at the end
      .replace(/M$/i, '')
      .replace(/W$/i, '')
      .trim();
    
    // Final cleanup: ensure it's just a number (with optional decimal)
    // This catches any remaining edge cases
    const match = normalized.match(/^(\d+(?:\.\d+)?)/);
    return match ? match[1] : normalized;
  }

  async fetchMarketPrices(
    styleCode: string,
    sku: string,
    size: string,
    productCondition: "new" | "used" | "pre-owned" = "new"
  ): Promise<{ comparables: InsertComparable[]; sources: string[]; imageUrl?: string }> {
    const comparables: InsertComparable[] = [];
    const sources: string[] = [];
    let imageUrl: string | undefined;
    const today = new Date().toISOString().split("T")[0];

    // For used/pre-owned shoes: skip StockX (new only), use only GOAT
    // For new shoes: use both StockX and GOAT
    const shouldUseStockX = productCondition === "new";

    const [stockxProduct, goatProduct] = await Promise.all([
      shouldUseStockX ? this.searchStockX(styleCode) : Promise.resolve(null),
      this.searchGOAT(styleCode),
    ]);

    // Normalize the product size for comparison
    const normalizedProductSize = this.normalizeSizeString(size);

    if (stockxProduct) {
      const productUrl = stockxProduct.link || `https://stockx.com/${stockxProduct.slug}`;
      
      // Try to find size-specific pricing from variants array
      if (stockxProduct.variants && stockxProduct.variants.length > 0) {
        // Look for exact size match
        const matchingVariant = stockxProduct.variants.find(v => 
          this.normalizeSizeString(v.size) === normalizedProductSize
        );
        
        if (matchingVariant) {
          // Found exact size match - use size-specific price!
          // StockX uses 'price' field
          const variantPrice = matchingVariant.price || matchingVariant.lowest_ask || 0;
          if (variantPrice > 0) {
            const { conditionType, conditionScore } = mapConditionToTypeAndScore("new");
            comparables.push({
              sku,
              styleCode,
              size,
              source: "stockx",
              listingType: "active", // StockX shows current ask prices (active listings)
              condition: "new", // StockX only sells new/deadstock
              conditionType,
              conditionScore,
              price: variantPrice,
              currency: matchingVariant.currency || "USD",
              fees: variantPrice * 0.095,
              shipping: 0,
              saleDate: today,
              productUrl,
            });
            sources.push("stockx");
          }
        } else {
          // No exact match - create comparables for all available sizes
          // This shows the user what sizes have pricing data
          const { conditionType, conditionScore } = mapConditionToTypeAndScore("new");
          stockxProduct.variants.slice(0, 5).forEach(variant => {
            const variantPrice = variant.price || variant.lowest_ask || 0;
            if (variantPrice > 0) {
              comparables.push({
                sku,
                styleCode,
                size: variant.size, // Use the actual variant size
                source: "stockx",
                listingType: "active",
                condition: "new",
                conditionType,
                conditionScore,
                price: variantPrice,
                currency: variant.currency || "USD",
                fees: variantPrice * 0.095,
                shipping: 0,
                saleDate: today,
                productUrl,
              });
            }
          });
          if (comparables.some(c => c.source === "stockx")) {
            sources.push("stockx");
          }
        }
      } else if (stockxProduct.avg_price) {
        // Fallback: No variants data, use averaged pricing
        const { conditionType, conditionScore } = mapConditionToTypeAndScore("new");
        comparables.push({
          sku,
          styleCode,
          size,
          source: "stockx",
          listingType: "active",
          condition: "new",
          conditionType,
          conditionScore,
          price: stockxProduct.avg_price,
          currency: "USD",
          fees: stockxProduct.avg_price * 0.095,
          shipping: 0,
          saleDate: today,
          productUrl,
        });
        sources.push("stockx");
      }
      
      // Get product image
      if (stockxProduct.image) {
        imageUrl = stockxProduct.image;
      } else if (stockxProduct.gallery && stockxProduct.gallery.length > 0) {
        imageUrl = stockxProduct.gallery[0];
      }
    }

    if (goatProduct) {
      const productUrl = goatProduct.link || `https://goat.com/sneakers/${goatProduct.slug}`;
      
      // Try to find size-specific pricing from variants array
      if (goatProduct.variants && goatProduct.variants.length > 0) {
        // Look for exact size match
        const matchingVariant = goatProduct.variants.find(v => 
          this.normalizeSizeString(v.size) === normalizedProductSize
        );
        
        if (matchingVariant) {
          // Found exact size match - use size-specific price!
          // GOAT uses 'lowest_ask' field instead of 'price'
          const variantPrice = matchingVariant.lowest_ask || matchingVariant.price || 0;
          const { conditionType, conditionScore } = mapConditionToTypeAndScore(productCondition);
          comparables.push({
            sku,
            styleCode,
            size,
            source: "goat",
            listingType: "active", // GOAT API returns current listings (not sold history yet)
            condition: productCondition, // Use product's condition - GOAT supports used/new
            conditionType,
            conditionScore,
            price: variantPrice,
            currency: matchingVariant.currency || "USD",
            fees: variantPrice * 0.095,
            shipping: 0,
            saleDate: today,
            productUrl,
          });
          sources.push("goat");
        } else {
          // No exact match - create comparables for all available sizes
          const { conditionType, conditionScore } = mapConditionToTypeAndScore(productCondition);
          goatProduct.variants.slice(0, 5).forEach(variant => {
            const variantPrice = variant.lowest_ask || variant.price || 0;
            comparables.push({
              sku,
              styleCode,
              size: variant.size,
              source: "goat",
              listingType: "active",
              condition: productCondition,
              conditionType,
              conditionScore,
              price: variantPrice,
              currency: variant.currency || "USD",
              fees: variantPrice * 0.095,
              shipping: 0,
              saleDate: today,
              productUrl,
            });
          });
          if (goatProduct.variants.length > 0) {
            sources.push("goat");
          }
        }
      } else if (goatProduct.avg_price) {
        // Fallback: No variants data, use averaged pricing
        const { conditionType, conditionScore } = mapConditionToTypeAndScore(productCondition);
        comparables.push({
          sku,
          styleCode,
          size,
          source: "goat",
          listingType: "active",
          condition: productCondition,
          conditionType,
          conditionScore,
          price: goatProduct.avg_price,
          currency: "USD",
          fees: goatProduct.avg_price * 0.095,
          shipping: 0,
          saleDate: today,
          productUrl,
        });
        sources.push("goat");
      }
      
      if (!imageUrl) {
        if (goatProduct.image) {
          imageUrl = goatProduct.image;
        } else if (goatProduct.gallery && goatProduct.gallery.length > 0) {
          imageUrl = goatProduct.gallery[0];
        }
      }
    }

    return { comparables, sources, imageUrl };
  }
}

export const kicksdb = new KicksDBService();

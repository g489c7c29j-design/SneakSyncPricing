import cron from "node-cron";
import { syncService } from "./sync-service";

export function startScheduler() {
  console.log("🔄 Starting background price sync scheduler (every 6 hours)");

  cron.schedule("0 */6 * * *", async () => {
    console.log("⏰ Running scheduled price sync...");
    try {
      const results = await syncService.syncAllProducts();
      const successCount = results.filter((r) => r.success).length;
      console.log(
        `✅ Sync complete: ${successCount}/${results.length} products updated`
      );
    } catch (error) {
      console.error("❌ Scheduled sync failed:", error);
    }
  });

  console.log("✓ Scheduler started - Next sync in ~6 hours");
}

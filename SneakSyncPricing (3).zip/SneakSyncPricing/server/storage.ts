import {
  type Product,
  type InsertProduct,
  type Comparable,
  type InsertComparable,
  type PriceSuggestion,
  type InsertPriceSuggestion,
  type AuditLog,
  type InsertAuditLog,
  type Rules,
  type InsertRules,
} from "@shared/schema";
import { randomUUID } from "crypto";

// Utility function to extract size from product name
export function extractSize(name: string): string | null {
  const sizeMatch = name.match(/Size\s+([\d.]+[YW]?)/i);
  return sizeMatch ? sizeMatch[1] : null;
}

// Utility function to extract condition from product name
export function extractCondition(name: string): "new" | "used" | "pre-owned" {
  const lowerName = name.toLowerCase();
  
  // Check for "pre-owned" FIRST (more specific than "used")
  if (lowerName.includes("pre-owned") || lowerName.includes("preowned") || lowerName.includes("pre owned")) {
    return "pre-owned";
  }
  
  // Check for "used" keywords (plain used = 15% discount)
  if (lowerName.includes("used") && !lowerName.includes("gently")) {
    return "used";
  }
  
  // Check for near-new conditions (VNDS, gently used = 15% discount)
  if (lowerName.includes("vnds") || lowerName.includes("very near deadstock") || lowerName.includes("gently used")) {
    return "used";
  }
  
  // Check for explicit "new" keywords (deadstock, brand new, DS, NIB, BNIB, etc.)
  if (lowerName.includes("deadstock") || lowerName.includes("brand new") || 
      lowerName.includes(" ds ") || lowerName.includes("nib") || lowerName.includes("bnib") ||
      lowerName.includes("new with box") || lowerName.includes("new in box")) {
    return "new";
  }
  
  // Default to "new" if no condition specified
  return "new";
}

// Utility function to map condition string to conditionType and score
export function mapConditionToTypeAndScore(condition: string): { 
  conditionType: "NEW" | "USED"; 
  conditionScore: number | null;
} {
  const lowerCondition = condition.toLowerCase();
  
  // NEW condition
  if (lowerCondition === "new" || lowerCondition === "deadstock" || lowerCondition === "brand new") {
    return { conditionType: "NEW", conditionScore: 10 };
  }
  
  // USED conditions with scores
  if (lowerCondition === "like new" || lowerCondition === "vnds" || lowerCondition === "very near deadstock") {
    return { conditionType: "USED", conditionScore: 9 };
  }
  
  if (lowerCondition === "very good" || lowerCondition === "gently used") {
    return { conditionType: "USED", conditionScore: 8 };
  }
  
  if (lowerCondition === "good" || lowerCondition === "used") {
    return { conditionType: "USED", conditionScore: 7 };
  }
  
  if (lowerCondition === "fair" || lowerCondition === "pre-owned" || lowerCondition === "pre owned" || lowerCondition === "preowned") {
    return { conditionType: "USED", conditionScore: 6 };
  }
  
  if (lowerCondition === "poor" || lowerCondition === "heavily used") {
    return { conditionType: "USED", conditionScore: 5 };
  }
  
  // Default to NEW if unrecognized
  return { conditionType: "NEW", conditionScore: 10 };
}

export interface IStorage {
  getProduct(sku: string): Promise<Product | undefined>;
  getAllProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(sku: string, updates: Partial<InsertProduct>): Promise<Product | undefined>;
  updateProductPrice(sku: string, newPrice: number): Promise<Product | undefined>;
  setProductProtection(sku: string, isProtected: boolean): Promise<Product | undefined>;
  updateProductSyncStatus(sku: string, status: string, lastSyncedAt?: Date): Promise<Product | undefined>;
  updateProductImage(sku: string, imageUrl: string): Promise<Product | undefined>;

  getComparablesBySku(sku: string): Promise<Comparable[]>;
  getComparablesByStyleCode(styleCode: string): Promise<Comparable[]>;
  createComparable(comparable: InsertComparable): Promise<Comparable>;
  createComparables(comparables: InsertComparable[]): Promise<Comparable[]>;

  getPriceSuggestion(id: string): Promise<PriceSuggestion | undefined>;
  getPendingPriceSuggestions(): Promise<PriceSuggestion[]>;
  getAllPriceSuggestions(): Promise<PriceSuggestion[]>;
  createPriceSuggestion(suggestion: InsertPriceSuggestion): Promise<PriceSuggestion>;
  updatePriceSuggestionStatus(id: string, status: string): Promise<PriceSuggestion | undefined>;
  deletePriceSuggestion(id: string): Promise<boolean>;

  getAuditLog(limit?: number): Promise<AuditLog[]>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;

  getRules(): Promise<Rules>;
  updateRules(rules: Partial<InsertRules>): Promise<Rules>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private comparables: Map<string, Comparable>;
  private priceSuggestions: Map<string, PriceSuggestion>;
  private auditLogs: AuditLog[];
  private rules: Rules;

  constructor() {
    this.products = new Map();
    this.comparables = new Map();
    this.priceSuggestions = new Map();
    this.auditLogs = [];
    this.rules = {
      id: randomUUID(),
      toleranceLowPct: 5,
      toleranceHighPct: 5,
      minMarginPct: 15,
      roundingMode: ".99",
      dailyCapPct: 10,
      cooldownMinutes: 120,
      autoUpdate: true,
    };

    this.seedData();
  }

  private seedData() {
    const realInventory: Array<Omit<InsertProduct, 'size'> & { name: string }> = [
      {
        sku: "BTV-001",
        styleCode: "DV0831-101",
        name: "Nike Dunk Low Sketch and Exploration - Size 10.5",
        currentPrice: 60.00,
        costBasis: 40.00,
        isProtected: false,
      },
      {
        sku: "BTV-002",
        styleCode: "FD0774-600",
        name: "Jordan 4 Retro SE Craft Photon Dust - Size 8",
        currentPrice: 80.00,
        costBasis: 55.00,
        isProtected: false,
      },
      {
        sku: "BTV-003",
        styleCode: "DM9652-102",
        name: "Jordan 1 Retro Low OG Mocha - Size 8.5",
        currentPrice: 100.00,
        costBasis: 70.00,
        isProtected: false,
      },
      {
        sku: "BTV-004",
        styleCode: "555088-105",
        name: "Jordan 1 Retro High Dark Mocha - Size 12",
        currentPrice: 250.00,
        costBasis: 175.00,
        isProtected: false,
      },
      {
        sku: "BTV-005",
        styleCode: "BQ0864-001",
        name: "Jordan 1 Retro High Zip AWOK Vogue Sail (Women's) - Size 7.5",
        currentPrice: 180.00,
        costBasis: 125.00,
        isProtected: false,
      },
      {
        sku: "BTV-006",
        styleCode: "DC7770-160",
        name: "Jordan 4 Retro Infrared - Size 10",
        currentPrice: 180.00,
        costBasis: 125.00,
        isProtected: false,
      },
      {
        sku: "BTV-007",
        styleCode: "FB9912-400",
        name: "Jordan 12 Retro Indigo (GS) - Size 6Y",
        currentPrice: 120.00,
        costBasis: 85.00,
        isProtected: false,
      },
      {
        sku: "BTV-008",
        styleCode: "DH9696-200",
        name: "Jordan 6 Retro Gore-Tex Brown Kelp (Women's) - Size 11.5W",
        currentPrice: 150.00,
        costBasis: 105.00,
        isProtected: false,
      },
      {
        sku: "BTV-009",
        styleCode: "DM1602-104",
        name: "Jordan 5 Retro UNC University Blue - Size 10",
        currentPrice: 250.00,
        costBasis: 175.00,
        isProtected: false,
      },
      {
        sku: "BTV-010",
        styleCode: "308497-100",
        name: "Jordan 4 Retro Pure Money (2017) - Size 12.5",
        currentPrice: 400.00,
        costBasis: 280.00,
        isProtected: false,
      },
      {
        sku: "BTV-011",
        styleCode: "308497-117",
        name: "Jordan 4 Retro Motorsports Alternate - Size 12.5",
        currentPrice: 300.00,
        costBasis: 210.00,
        isProtected: false,
      },
      {
        sku: "BTV-012",
        styleCode: "308497-007",
        name: "Jordan 4 Retro Cool Grey (2019) - Size 12.5",
        currentPrice: 260.00,
        costBasis: 180.00,
        isProtected: false,
      },
      {
        sku: "BTV-013",
        styleCode: "FV2473-900",
        name: "Nike Kobe 8 Protro What The (2025) - Size 10.5",
        currentPrice: 240.00,
        costBasis: 170.00,
        isProtected: false,
      },
      {
        sku: "BTV-014",
        styleCode: "DR8609-300",
        name: "Nike Cortez 72 Shoe Dog Dimension Six Moon - Size 10.5",
        currentPrice: 50.00,
        costBasis: 35.00,
        isProtected: false,
      },
      {
        sku: "BTV-015",
        styleCode: "DN3707-100",
        name: "Jordan 3 Retro White Cement Reimagined - Size 10.5",
        currentPrice: 300.00,
        costBasis: 210.00,
        isProtected: false,
      },
      {
        sku: "BTV-016",
        styleCode: "FD9082-100",
        name: "Nike Air Max 1 Time Capsule Pack - Size 10.5",
        currentPrice: 60.00,
        costBasis: 40.00,
        isProtected: false,
      },
      {
        sku: "BTV-017",
        styleCode: "DD1869-101",
        name: "Nike Dunk High Syracuse (2021) (Women's) Used - Size 12W",
        currentPrice: 40.00,
        costBasis: 28.00,
        isProtected: false,
      },
      {
        sku: "BTV-018",
        styleCode: "DX2559-200",
        name: "Nike Air Force 1 Low '07 Cacao Wow Pre-Owned - Size 9.5",
        currentPrice: 60.00,
        costBasis: 40.00,
        isProtected: false,
      },
      {
        sku: "BTV-019",
        styleCode: "GS4701-700",
        name: "Nike Air Force 1 Low LV8 GS 'Gold' Used - Size 5Y",
        currentPrice: 45.00,
        costBasis: 30.00,
        isProtected: false,
      },
      {
        sku: "BTV-020",
        styleCode: "CZ5127-001",
        name: "Nike SB Dunk Low Medicom Toy (2020) - Size 8",
        currentPrice: 150.00,
        costBasis: 105.00,
        isProtected: false,
      },
    ];

    realInventory.forEach((p) => {
      const extractedCondition = extractCondition(p.name);
      const { conditionType, conditionScore } = mapConditionToTypeAndScore(extractedCondition);
      
      const product: Product = {
        id: randomUUID(),
        sku: p.sku,
        styleCode: p.styleCode,
        name: p.name,
        size: extractSize(p.name),
        condition: extractedCondition,
        conditionType,
        conditionScore,
        conditionNotes: null,
        currentPrice: p.currentPrice,
        costBasis: p.costBasis,
        isProtected: p.isProtected ?? false,
        imageUrl: p.imageUrl ?? null,
        lastUpdated: new Date(),
        lastSyncedAt: null,
        syncStatus: null,
      };
      this.products.set(p.sku, product);
    });

    // Add sample comparables for demonstration
    this.seedSampleComparables();
  }

  private seedSampleComparables() {
    const today = new Date().toISOString().split("T")[0];
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    const twoDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    // Sample comparables for BTV-001 (Nike Dunk Low Sketch)
    const sampleComparables: InsertComparable[] = [
      {
        sku: "BTV-001",
        styleCode: "DV0831-101",
        size: "10.5",
        source: "stockx",
        listingType: "sold",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 65.00,
        currency: "USD",
        fees: 6.50,
        shipping: 0,
        saleDate: yesterday,
        productUrl: "https://stockx.com/nike-dunk-low-sketch",
      },
      {
        sku: "BTV-001",
        styleCode: "DV0831-101",
        size: "10.5",
        source: "goat",
        listingType: "sold",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 63.00,
        currency: "USD",
        fees: 6.30,
        shipping: 0,
        saleDate: today,
        productUrl: "https://goat.com/sneakers/nike-dunk-low-sketch",
      },
      {
        sku: "BTV-001",
        styleCode: "DV0831-101",
        size: "10.5",
        source: "stockx",
        listingType: "active",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 67.00,
        currency: "USD",
        fees: 6.70,
        shipping: 0,
        saleDate: today,
        productUrl: "https://stockx.com/nike-dunk-low-sketch",
      },
      // Sample comparables for BTV-004 (Jordan 1 Dark Mocha)
      {
        sku: "BTV-004",
        styleCode: "555088-105",
        size: "12",
        source: "stockx",
        listingType: "sold",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 255.00,
        currency: "USD",
        fees: 25.50,
        shipping: 0,
        saleDate: twoDaysAgo,
        productUrl: "https://stockx.com/jordan-1-dark-mocha",
      },
      {
        sku: "BTV-004",
        styleCode: "555088-105",
        size: "12",
        source: "goat",
        listingType: "sold",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 260.00,
        currency: "USD",
        fees: 26.00,
        shipping: 0,
        saleDate: yesterday,
        productUrl: "https://goat.com/sneakers/jordan-1-dark-mocha",
      },
      {
        sku: "BTV-004",
        styleCode: "555088-105",
        size: "12",
        source: "stockx",
        listingType: "active",
        condition: "new",
        conditionType: "NEW",
        conditionScore: null,
        price: 265.00,
        currency: "USD",
        fees: 26.50,
        shipping: 0,
        saleDate: today,
        productUrl: "https://stockx.com/jordan-1-dark-mocha",
      },
    ];

    sampleComparables.forEach((comp) => {
      const comparable: Comparable = {
        id: randomUUID(),
        sku: comp.sku,
        styleCode: comp.styleCode,
        size: comp.size ?? null,
        source: comp.source,
        listingType: comp.listingType ?? "sold",
        condition: comp.condition ?? "new",
        conditionType: comp.conditionType ?? "NEW",
        conditionScore: comp.conditionScore ?? null,
        price: comp.price,
        currency: comp.currency ?? "USD",
        fees: comp.fees ?? 0,
        shipping: comp.shipping ?? 0,
        saleDate: comp.saleDate,
        productUrl: comp.productUrl ?? null,
        importedAt: new Date(),
      };
      this.comparables.set(comparable.id, comparable);
    });
  }

  async getProduct(sku: string): Promise<Product | undefined> {
    return this.products.get(sku);
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const product: Product = {
      id: randomUUID(),
      sku: insertProduct.sku,
      styleCode: insertProduct.styleCode,
      name: insertProduct.name,
      size: insertProduct.size ?? null,
      condition: insertProduct.condition ?? "new",
      conditionType: insertProduct.conditionType ?? "NEW",
      conditionScore: insertProduct.conditionScore ?? null,
      conditionNotes: insertProduct.conditionNotes ?? null,
      currentPrice: insertProduct.currentPrice,
      costBasis: insertProduct.costBasis,
      isProtected: insertProduct.isProtected ?? false,
      imageUrl: insertProduct.imageUrl ?? null,
      lastUpdated: new Date(),
      lastSyncedAt: null,
      syncStatus: null,
    };
    this.products.set(insertProduct.sku, product);
    return product;
  }

  async updateProduct(sku: string, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(sku);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      ...updates,
      lastUpdated: new Date(),
    };
    this.products.set(sku, updated);
    return updated;
  }

  async updateProductPrice(sku: string, newPrice: number): Promise<Product | undefined> {
    const product = this.products.get(sku);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      currentPrice: newPrice,
      lastUpdated: new Date(),
    };
    this.products.set(sku, updated);
    return updated;
  }

  async setProductProtection(sku: string, isProtected: boolean): Promise<Product | undefined> {
    const product = this.products.get(sku);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      isProtected,
      lastUpdated: new Date(),
    };
    this.products.set(sku, updated);
    return updated;
  }

  async updateProductSyncStatus(sku: string, status: string, lastSyncedAt?: Date): Promise<Product | undefined> {
    const product = this.products.get(sku);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      syncStatus: status,
      lastSyncedAt: lastSyncedAt || new Date(),
    };
    this.products.set(sku, updated);
    return updated;
  }

  async updateProductImage(sku: string, imageUrl: string): Promise<Product | undefined> {
    const product = this.products.get(sku);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      imageUrl,
    };
    this.products.set(sku, updated);
    return updated;
  }

  async getComparablesBySku(sku: string): Promise<Comparable[]> {
    return Array.from(this.comparables.values()).filter((c) => c.sku === sku);
  }

  async getComparablesByStyleCode(styleCode: string): Promise<Comparable[]> {
    return Array.from(this.comparables.values()).filter(
      (c) => c.styleCode === styleCode
    );
  }

  async createComparable(insertComparable: InsertComparable): Promise<Comparable> {
    // If conditionType/Score not provided, derive from condition string
    let conditionType = insertComparable.conditionType ?? "NEW";
    let conditionScore = insertComparable.conditionScore ?? null;
    
    if (!insertComparable.conditionType && insertComparable.condition) {
      const mapped = mapConditionToTypeAndScore(insertComparable.condition);
      conditionType = mapped.conditionType;
      conditionScore = mapped.conditionScore;
    }
    
    const comparable: Comparable = {
      id: randomUUID(),
      sku: insertComparable.sku,
      styleCode: insertComparable.styleCode,
      size: insertComparable.size ?? null,
      source: insertComparable.source,
      listingType: insertComparable.listingType ?? "sold",
      condition: insertComparable.condition ?? null,
      conditionType,
      conditionScore,
      price: insertComparable.price,
      currency: insertComparable.currency ?? "USD",
      fees: insertComparable.fees ?? 0,
      shipping: insertComparable.shipping ?? 0,
      saleDate: insertComparable.saleDate,
      productUrl: insertComparable.productUrl ?? null,
      importedAt: new Date(),
    };
    this.comparables.set(comparable.id, comparable);
    return comparable;
  }

  async createComparables(insertComparables: InsertComparable[]): Promise<Comparable[]> {
    const created: Comparable[] = [];
    for (const insert of insertComparables) {
      const comparable = await this.createComparable(insert);
      created.push(comparable);
    }
    return created;
  }

  async getPriceSuggestion(id: string): Promise<PriceSuggestion | undefined> {
    return this.priceSuggestions.get(id);
  }

  async getPendingPriceSuggestions(): Promise<PriceSuggestion[]> {
    return Array.from(this.priceSuggestions.values()).filter(
      (s) => s.status === "pending"
    );
  }

  async getAllPriceSuggestions(): Promise<PriceSuggestion[]> {
    return Array.from(this.priceSuggestions.values());
  }

  async createPriceSuggestion(
    insertSuggestion: InsertPriceSuggestion
  ): Promise<PriceSuggestion> {
    const suggestion: PriceSuggestion = {
      ...insertSuggestion,
      id: randomUUID(),
      createdAt: new Date(),
    };
    this.priceSuggestions.set(suggestion.id, suggestion);
    return suggestion;
  }

  async updatePriceSuggestionStatus(
    id: string,
    status: string
  ): Promise<PriceSuggestion | undefined> {
    const suggestion = this.priceSuggestions.get(id);
    if (!suggestion) return undefined;

    const updated: PriceSuggestion = {
      ...suggestion,
      status,
    };
    this.priceSuggestions.set(id, updated);
    return updated;
  }

  async deletePriceSuggestion(id: string): Promise<boolean> {
    return this.priceSuggestions.delete(id);
  }

  async getAuditLog(limit: number = 100): Promise<AuditLog[]> {
    return this.auditLogs
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async createAuditLog(insertLog: InsertAuditLog): Promise<AuditLog> {
    const log: AuditLog = {
      id: randomUUID(),
      timestamp: new Date(),
      action: insertLog.action,
      sku: insertLog.sku,
      productName: insertLog.productName,
      oldPrice: insertLog.oldPrice,
      newPrice: insertLog.newPrice,
      delta: insertLog.delta,
      user: insertLog.user ?? null,
    };
    this.auditLogs.push(log);
    return log;
  }

  async getRules(): Promise<Rules> {
    return this.rules;
  }

  async updateRules(partial: Partial<InsertRules>): Promise<Rules> {
    this.rules = {
      ...this.rules,
      ...partial,
    };
    return this.rules;
  }
}

export const storage = new MemStorage();

import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sku: text("sku").notNull().unique(),
  styleCode: text("style_code").notNull(),
  name: text("name").notNull(),
  size: text("size"),
  condition: text("condition").notNull().default("new"), // Legacy display field
  conditionType: text("condition_type").notNull().default("NEW"), // "NEW" or "USED"
  conditionScore: integer("condition_score"), // 1-10 scale for USED items (10=New, 9=Like New, 8=Very Good, etc.)
  conditionNotes: text("condition_notes"), // Optional notes about condition
  currentPrice: real("current_price").notNull(),
  costBasis: real("cost_basis").notNull(),
  isProtected: boolean("is_protected").notNull().default(false),
  imageUrl: text("image_url"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  lastSyncedAt: timestamp("last_synced_at"),
  syncStatus: text("sync_status"),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  lastUpdated: true,
  lastSyncedAt: true,
  syncStatus: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export const comparables = pgTable("comparables", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sku: text("sku").notNull(),
  styleCode: text("style_code").notNull(),
  size: text("size"),
  source: text("source").notNull(),
  listingType: text("listing_type").notNull().default("active"), // "sold" or "active"
  condition: text("condition").default("new"), // Legacy display field
  conditionType: text("condition_type").notNull().default("NEW"), // "NEW" or "USED"
  conditionScore: integer("condition_score"), // 1-10 scale for USED items
  price: real("price").notNull(),
  currency: text("currency").notNull().default("USD"),
  fees: real("fees").notNull().default(0),
  shipping: real("shipping").notNull().default(0),
  saleDate: text("sale_date").notNull(),
  productUrl: text("product_url"),
  importedAt: timestamp("imported_at").notNull().defaultNow(),
});

export const insertComparableSchema = createInsertSchema(comparables).omit({
  id: true,
  importedAt: true,
});

export type InsertComparable = z.infer<typeof insertComparableSchema>;
export type Comparable = typeof comparables.$inferSelect;

export const priceSuggestions = pgTable("price_suggestions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: text("product_id").notNull(),
  sku: text("sku").notNull(),
  currentPrice: real("current_price").notNull(),
  suggestedPrice: real("suggested_price").notNull(),
  delta: real("delta").notNull(),
  status: text("status").notNull(),
  decision: text("decision").notNull(),
  sourceCount: integer("source_count").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPriceSuggestionSchema = createInsertSchema(priceSuggestions).omit({
  id: true,
  createdAt: true,
});

export type InsertPriceSuggestion = z.infer<typeof insertPriceSuggestionSchema>;
export type PriceSuggestion = typeof priceSuggestions.$inferSelect;

export const auditLog = pgTable("audit_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  action: text("action").notNull(),
  sku: text("sku").notNull(),
  productName: text("product_name").notNull(),
  oldPrice: real("old_price").notNull(),
  newPrice: real("new_price").notNull(),
  delta: real("delta").notNull(),
  user: text("user"),
});

export const insertAuditLogSchema = createInsertSchema(auditLog).omit({
  id: true,
  timestamp: true,
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLog.$inferSelect;

export const rules = pgTable("rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  toleranceLowPct: real("tolerance_low_pct").notNull().default(5),
  toleranceHighPct: real("tolerance_high_pct").notNull().default(5),
  minMarginPct: real("min_margin_pct").notNull().default(15),
  roundingMode: text("rounding_mode").notNull().default(".99"),
  dailyCapPct: real("daily_cap_pct").notNull().default(10),
  cooldownMinutes: integer("cooldown_minutes").notNull().default(120),
  autoUpdate: boolean("auto_update").notNull().default(true),
});

export const insertRulesSchema = createInsertSchema(rules).omit({
  id: true,
});

export type InsertRules = z.infer<typeof insertRulesSchema>;
export type Rules = typeof rules.$inferSelect;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

import { PriceComparisonTable, type PriceRow } from "@/components/PriceComparisonTable";
import { Button } from "@/components/ui/button";
import { Check, X } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Approvals() {
  const { toast } = useToast();

  const { data: approvalsData } = useQuery<{ ok: boolean; approvals: PriceRow[] }>({
    queryKey: ["/api/approvals"],
  });

  const approveMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Approved",
        description: "The price update has been approved and applied.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/approvals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/reject`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Rejected",
        description: "The price update has been rejected.",
        variant: "destructive",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/approvals"] });
    },
  });

  const approvals: PriceRow[] = approvalsData?.approvals || [];

  const handleApproveAll = async () => {
    for (const approval of approvals) {
      await approveMutation.mutateAsync(approval.sku);
    }
    toast({
      title: "All Prices Approved",
      description: `${approvals.length} price updates have been approved.`,
    });
  };

  const handleRejectAll = async () => {
    for (const approval of approvals) {
      await rejectMutation.mutateAsync(approval.sku);
    }
    toast({
      title: "All Prices Rejected",
      description: `${approvals.length} price updates have been rejected.`,
      variant: "destructive",
    });
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Approvals Queue</h1>
          <p className="text-sm md:text-base text-muted-foreground mt-1">
            Review and approve price changes outside tolerance limits
          </p>
        </div>
        {approvals.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={handleRejectAll}
              disabled={rejectMutation.isPending}
              data-testid="button-reject-all"
              className="w-full sm:w-auto"
            >
              <X className="h-4 w-4 mr-2" />
              Reject All
            </Button>
            <Button
              onClick={handleApproveAll}
              disabled={approveMutation.isPending}
              data-testid="button-approve-all"
              className="w-full sm:w-auto"
            >
              <Check className="h-4 w-4 mr-2" />
              Approve All
            </Button>
          </div>
        )}
      </div>

      {approvals.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Check className="h-16 w-16 text-success mb-4" />
          <h3 className="text-xl font-semibold mb-2">All caught up!</h3>
          <p className="text-muted-foreground">
            No pending price approvals at the moment.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-warning/10 border border-warning/20 rounded-md p-4">
            <p className="text-sm">
              <span className="font-semibold">{approvals.length} items</span>{" "}
              require approval due to price changes exceeding tolerance limits
            </p>
          </div>

          <PriceComparisonTable
            data={approvals}
            onApprove={(id) => {
              const product = approvals.find((p) => p.id === id);
              if (product) approveMutation.mutate(product.sku);
            }}
            onReject={(id) => {
              const product = approvals.find((p) => p.id === id);
              if (product) rejectMutation.mutate(product.sku);
            }}
            testId="approvals-table"
          />
        </div>
      )}
    </div>
  );
}

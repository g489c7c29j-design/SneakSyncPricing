import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

interface AuditEntry {
  id: string;
  timestamp: string;
  action: "auto_update" | "approved" | "rejected" | "manual";
  sku: string;
  productName: string;
  oldPrice: number;
  newPrice: number;
  delta: number;
  user?: string | null;
}

const actionConfig = {
  auto_update: {
    label: "Auto-updated",
    className: "bg-success/10 text-success",
  },
  approved: {
    label: "Approved",
    className: "bg-info/10 text-info",
  },
  rejected: {
    label: "Rejected",
    className: "bg-destructive/10 text-destructive",
  },
  manual: {
    label: "Manual",
    className: "bg-muted text-muted-foreground",
  },
};

export default function AuditLog() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: logsData } = useQuery<{ ok: boolean; logs: AuditEntry[] }>({
    queryKey: ["/api/audit-log"],
  });

  const allLogs = logsData?.logs || [];

  const filteredLog = allLogs.filter((entry) =>
    entry.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4 md:space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Audit Log</h1>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          Complete history of all pricing decisions and changes
        </p>
      </div>

      <div className="relative w-full md:max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by SKU or product..."
          className="pl-9"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          data-testid="input-search"
        />
      </div>

      {filteredLog.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">
          No audit log entries found.
        </p>
      ) : (
        <div className="space-y-3">
          {filteredLog.map((entry) => (
            <Card
              key={entry.id}
              className="p-4 hover-elevate"
              data-testid={`audit-entry-${entry.id}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge
                      variant="secondary"
                      className={actionConfig[entry.action].className}
                    >
                      {actionConfig[entry.action].label}
                    </Badge>
                    <span className="font-mono text-sm font-medium">{entry.sku}</span>
                    <span className="text-sm text-muted-foreground">•</span>
                    <span className="font-medium">{entry.productName}</span>
                    {entry.user && (
                      <>
                        <span className="text-sm text-muted-foreground">•</span>
                        <span className="text-sm text-muted-foreground">
                          by {entry.user}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Old:</span>
                      <span className="font-mono font-bold">
                        ${entry.oldPrice.toFixed(2)}
                      </span>
                    </div>
                    <span className="text-muted-foreground">→</span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">New:</span>
                      <span className="font-mono font-bold">
                        ${entry.newPrice.toFixed(2)}
                      </span>
                    </div>
                    <Badge
                      variant="secondary"
                      className={`font-mono ${
                        entry.delta > 0 ? "text-success" : "text-info"
                      }`}
                    >
                      {entry.delta > 0 ? "+" : ""}
                      {entry.delta.toFixed(1)}%
                    </Badge>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-sm text-muted-foreground">{entry.timestamp}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

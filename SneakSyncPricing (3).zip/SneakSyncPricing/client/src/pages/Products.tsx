import { PriceComparisonTable, type PriceRow } from "@/components/PriceComparisonTable";
import { CreateProductDialog } from "@/components/CreateProductDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Products() {
  const [filter, setFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: productsData } = useQuery<{ ok: boolean; products: PriceRow[] }>({
    queryKey: ["/api/products"],
  });

  const approveMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Approved",
        description: "The price update has been approved and applied.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/reject`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Rejected",
        description: "The price update has been rejected.",
        variant: "destructive",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const allProducts: PriceRow[] = productsData?.products || [];

  const filteredProducts = allProducts.filter((product) => {
    const matchesFilter = filter === "all" || product.status === filter;
    const matchesSearch =
      product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.productName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Products</h1>
          <p className="text-sm md:text-base text-muted-foreground mt-1">
            Manage pricing for all your inventory
          </p>
        </div>
        <CreateProductDialog />
      </div>

      <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by SKU or product name..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search"
          />
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-filter">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="auto-updated">Auto-updated</SelectItem>
            <SelectItem value="protected">Protected</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredProducts.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">
          No products match your filters.
        </p>
      ) : (
        <PriceComparisonTable
          data={filteredProducts}
          onApprove={(id) => {
            const product = filteredProducts.find((p) => p.id === id);
            if (product) approveMutation.mutate(product.sku);
          }}
          onReject={(id) => {
            const product = filteredProducts.find((p) => p.id === id);
            if (product) rejectMutation.mutate(product.sku);
          }}
          testId="products-table"
        />
      )}
    </div>
  );
}

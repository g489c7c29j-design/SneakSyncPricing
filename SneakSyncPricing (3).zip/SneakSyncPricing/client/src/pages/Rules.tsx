import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Rules() {
  const { toast } = useToast();

  const { data: rulesData } = useQuery<{ ok: boolean; rules: typeof config }>({
    queryKey: ["/api/rules"],
  });

  const [config, setConfig] = useState({
    toleranceLowPct: 5,
    toleranceHighPct: 5,
    minMarginPct: 15,
    roundingMode: ".99",
    dailyCapPct: 10,
    cooldownMinutes: 120,
    autoUpdate: true,
  });

  useEffect(() => {
    if (rulesData?.rules) {
      setConfig(rulesData.rules);
    }
  }, [rulesData]);

  const saveMutation = useMutation({
    mutationFn: async (rules: typeof config) => {
      const res = await apiRequest("POST", "/api/rules", rules);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Rules Saved",
        description: "Pricing rules have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rules"] });
    },
  });

  const handleSave = () => {
    saveMutation.mutate(config);
  };

  return (
    <div className="space-y-4 md:space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Pricing Rules</h1>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          Configure automatic pricing behavior and safety guardrails
        </p>
      </div>

      <Card data-testid="rules-config">
        <CardHeader>
          <CardTitle>Pricing Rules & Guardrails</CardTitle>
          <CardDescription>
            Configure automatic price update behavior and safety limits
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Label htmlFor="auto-update">Enable Auto-Updates</Label>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Automatically update prices within tolerance limits
                  </TooltipContent>
                </Tooltip>
              </div>
              <Switch
                id="auto-update"
                checked={config.autoUpdate}
                onCheckedChange={(checked) =>
                  setConfig({ ...config, autoUpdate: checked })
                }
                data-testid="rules-config-auto-update"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label htmlFor="tolerance-low">Tolerance Low (%)</Label>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Auto-update if decrease is within {config.toleranceLowPct}%
                    </TooltipContent>
                  </Tooltip>
                </div>
                <Input
                  id="tolerance-low"
                  type="number"
                  value={config.toleranceLowPct}
                  onChange={(e) =>
                    setConfig({ ...config, toleranceLowPct: Number(e.target.value) })
                  }
                  data-testid="rules-config-tolerance"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label htmlFor="tolerance-high">Tolerance High (%)</Label>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Auto-update if increase is within {config.toleranceHighPct}%
                    </TooltipContent>
                  </Tooltip>
                </div>
                <Input
                  id="tolerance-high"
                  type="number"
                  value={config.toleranceHighPct}
                  onChange={(e) =>
                    setConfig({ ...config, toleranceHighPct: Number(e.target.value) })
                  }
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label htmlFor="margin">Min Margin (%)</Label>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Never price below cost × (1 + {config.minMarginPct}%)
                    </TooltipContent>
                  </Tooltip>
                </div>
                <Input
                  id="margin"
                  type="number"
                  value={config.minMarginPct}
                  onChange={(e) =>
                    setConfig({ ...config, minMarginPct: Number(e.target.value) })
                  }
                  data-testid="rules-config-margin"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rounding">Price Rounding</Label>
                <Select
                  value={config.roundingMode}
                  onValueChange={(value) =>
                    setConfig({ ...config, roundingMode: value })
                  }
                >
                  <SelectTrigger id="rounding" data-testid="rules-config-rounding">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value=".99">.99</SelectItem>
                    <SelectItem value=".95">.95</SelectItem>
                    <SelectItem value=".00">.00</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label htmlFor="daily-cap">Daily Cap (%)</Label>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Maximum price movement per day
                    </TooltipContent>
                  </Tooltip>
                </div>
                <Input
                  id="daily-cap"
                  type="number"
                  value={config.dailyCapPct}
                  onChange={(e) =>
                    setConfig({ ...config, dailyCapPct: Number(e.target.value) })
                  }
                  data-testid="rules-config-daily-cap"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label htmlFor="cooldown">Cooldown (minutes)</Label>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Wait time between auto-updates for the same product
                    </TooltipContent>
                  </Tooltip>
                </div>
                <Input
                  id="cooldown"
                  type="number"
                  value={config.cooldownMinutes}
                  onChange={(e) =>
                    setConfig({ ...config, cooldownMinutes: Number(e.target.value) })
                  }
                  data-testid="rules-config-cooldown"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t">
            <h4 className="font-semibold mb-3 text-sm">Example Calculation</h4>
            <div className="p-4 bg-muted rounded-md space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Cost Basis:</span>
                <span className="font-mono">$100.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Min Price ({config.minMarginPct}% margin):</span>
                <span className="font-mono">${(100 * (1 + config.minMarginPct / 100)).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Market Baseline:</span>
                <span className="font-mono">$129.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Rounded Price ({config.roundingMode}):</span>
                <span className="font-mono font-bold">
                  ${config.roundingMode === ".99" ? "128.99" : config.roundingMode === ".95" ? "128.95" : "129.00"}
                </span>
              </div>
            </div>
          </div>

          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="w-full"
            data-testid="rules-config-save"
          >
            {saveMutation.isPending ? "Saving..." : "Save Rules"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

import { StatsCard } from "@/components/StatsCard";
import { PriceComparisonTable, type PriceRow } from "@/components/PriceComparisonTable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Upload, RefreshCw, Download, Info } from "lucide-react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: stats } = useQuery<{ ok: boolean; stats: { autoUpdatesToday: number; pendingApprovals: number; avgDelta: string; marginProtected: string } }>({
    queryKey: ["/api/stats"],
  });

  const { data: productsData } = useQuery<{ ok: boolean; products: PriceRow[] }>({
    queryKey: ["/api/products"],
  });

  const computePricesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/compute-prices");
      return res.json() as Promise<{ ok: boolean; autoUpdated: number }>;
    },
    onSuccess: (data: { ok: boolean; autoUpdated: number }) => {
      toast({
        title: "Prices Computed",
        description: `${data.autoUpdated} products auto-updated.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Approved",
        description: "The price update has been approved and applied.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (sku: string) => {
      const res = await apiRequest("POST", `/api/approvals/${sku}/reject`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Rejected",
        description: "The price update has been rejected.",
        variant: "destructive",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const syncPricesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/sync/all");
      return res.json() as Promise<{ ok: boolean; summary: { total: number; success: number; failed: number } }>;
    },
    onSuccess: (data) => {
      toast({
        title: "Price Sync Complete",
        description: `${data.summary.success} of ${data.summary.total} products synced successfully.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Failed to sync prices from marketplaces.",
        variant: "destructive",
      });
    },
  });

  const recentUpdates: PriceRow[] = productsData?.products?.slice(0, 5) || [];

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Dashboard</h1>
          <p className="text-sm md:text-base text-muted-foreground mt-1">
            Overview of pricing automation activity
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={() => syncPricesMutation.mutate()}
            disabled={syncPricesMutation.isPending}
            data-testid="button-sync"
            className="w-full sm:w-auto"
          >
            <Download className={`h-4 w-4 mr-2 ${syncPricesMutation.isPending ? "animate-spin" : ""}`} />
            Sync Prices
          </Button>
          <Button
            variant="outline"
            onClick={() => computePricesMutation.mutate()}
            disabled={computePricesMutation.isPending}
            data-testid="button-refresh"
            className="w-full sm:w-auto"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${computePricesMutation.isPending ? "animate-spin" : ""}`} />
            Compute Prices
          </Button>
          <Link href="/import">
            <Button data-testid="button-import" className="w-full sm:w-auto">
              <Upload className="h-4 w-4 mr-2" />
              Import CSV
            </Button>
          </Link>
        </div>
      </div>

      <Alert data-testid="alert-size-info">
        <Info className="h-4 w-4" />
        <AlertTitle>Size-Aware Pricing</AlertTitle>
        <AlertDescription>
          Market data is fetched from StockX and GOAT variant-level pricing. 
          Comparables show size-specific prices when available, with automatic fallback for averaged market data.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          label="Auto-updates Today"
          value={stats?.stats?.autoUpdatesToday || 0}
          testId="stat-auto-updates"
        />
        <StatsCard
          label="Pending Approvals"
          value={stats?.stats?.pendingApprovals || 0}
          testId="stat-pending"
        />
        <StatsCard
          label="Avg. Delta %"
          value={`${stats?.stats?.avgDelta || 0}%`}
          testId="stat-delta"
        />
        <StatsCard
          label="Margin Protected"
          value={`${stats?.stats?.marginProtected || 0}%`}
          testId="stat-margin"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Price Updates</CardTitle>
          <CardDescription>
            Latest pricing changes across your inventory
          </CardDescription>
        </CardHeader>
        <CardContent>
          {recentUpdates.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No products available. Import comparable data to get started.
            </p>
          ) : (
            <PriceComparisonTable
              data={recentUpdates}
              onApprove={(id) => {
                const product = recentUpdates.find((p) => p.id === id);
                if (product) approveMutation.mutate(product.sku);
              }}
              onReject={(id) => {
                const product = recentUpdates.find((p) => p.id === id);
                if (product) rejectMutation.mutate(product.sku);
              }}
              testId="recent-updates-table"
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download } from "lucide-react";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";

export default function Import() {
  const [csvContent, setCsvContent] = useState("");
  const { toast } = useToast();

  const importMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/import/csv", { csvContent: content });
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Import Successful",
        description: `Imported ${data.imported} comparable data points.`,
      });
      setCsvContent("");
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import CSV data.",
        variant: "destructive",
      });
    },
  });

  const handleImport = () => {
    if (csvContent.trim()) {
      importMutation.mutate(csvContent);
    }
  };

  const handleDownloadTemplate = () => {
    const template = `source,sku,style_code,price,currency,fees,shipping,date
ebay,CZ0790-110,CZ0790-110,265.00,USD,26.50,0.00,2025-10-20
stockx,CZ0790-110,CZ0790-110,260.00,USD,26.00,0.00,2025-10-19
goat,DD1391-100,DD1391-100,125.00,USD,12.50,0.00,2025-10-20`;

    const blob = new Blob([template], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sneaksync-template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 md:space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Import Comps Data</h1>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          Upload CSV files with comparable pricing data from eBay, StockX, or GOAT
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Paste CSV Data</CardTitle>
          <CardDescription>
            Copy and paste your CSV content below
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="source,sku,style_code,price,currency,fees,shipping,date&#10;ebay,CZ0790-110,CZ0790-110,265.00,USD,26.50,0.00,2025-10-20"
            className="font-mono text-sm min-h-[200px]"
            value={csvContent}
            onChange={(e) => setCsvContent(e.target.value)}
            data-testid="textarea-csv"
          />
          <Button
            onClick={handleImport}
            disabled={!csvContent.trim() || importMutation.isPending}
            className="w-full"
            data-testid="button-import"
          >
            {importMutation.isPending ? "Importing..." : "Import CSV Data"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            CSV Format Requirements
          </CardTitle>
          <CardDescription>
            Your CSV file should include these columns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-md font-mono text-sm overflow-x-auto">
              <div className="whitespace-nowrap">
                source,sku,style_code,price,currency,fees,shipping,date
              </div>
              <div className="whitespace-nowrap text-muted-foreground mt-2">
                ebay,CZ0790-110,CZ0790-110,265.00,USD,26.50,0.00,2025-10-20
              </div>
            </div>

            <div className="grid gap-3">
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">source</span>
                <span className="text-sm text-muted-foreground">
                  Data source (ebay, stockx, goat, csv)
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">sku</span>
                <span className="text-sm text-muted-foreground">
                  Your internal SKU identifier
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">style_code</span>
                <span className="text-sm text-muted-foreground">
                  Manufacturer style code (e.g., CZ0790-110)
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">price</span>
                <span className="text-sm text-muted-foreground">
                  Sold price (numeric)
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">currency</span>
                <span className="text-sm text-muted-foreground">
                  Currency code (USD, EUR, etc.)
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">fees</span>
                <span className="text-sm text-muted-foreground">
                  Platform/seller fees
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">shipping</span>
                <span className="text-sm text-muted-foreground">
                  Shipping cost
                </span>
              </div>
              <div className="flex gap-3">
                <span className="font-mono text-sm font-semibold min-w-[120px]">date</span>
                <span className="text-sm text-muted-foreground">
                  Sale date (YYYY-MM-DD)
                </span>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={handleDownloadTemplate}
              data-testid="button-download-template"
            >
              <Download className="h-4 w-4 mr-2" />
              Download CSV Template
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

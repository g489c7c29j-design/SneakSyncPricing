import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StatsCardProps {
  label: string;
  value: string | number;
  trend?: {
    direction: "up" | "down";
    value: string;
  };
  testId?: string;
}

export function StatsCard({ label, value, trend, testId }: StatsCardProps) {
  return (
    <Card className="p-6" data-testid={testId}>
      <div className="flex flex-col gap-2">
        <p className="text-sm text-muted-foreground">{label}</p>
        <div className="flex items-baseline gap-2">
          <h3 className="text-3xl font-bold" data-testid={`${testId}-value`}>
            {value}
          </h3>
          {trend && (
            <span
              className={`flex items-center gap-1 text-sm font-medium ${
                trend.direction === "up" ? "text-success" : "text-info"
              }`}
              data-testid={`${testId}-trend`}
            >
              {trend.direction === "up" ? (
                <TrendingUp className="h-4 w-4" />
              ) : (
                <TrendingDown className="h-4 w-4" />
              )}
              {trend.value}
            </span>
          )}
        </div>
      </div>
    </Card>
  );
}

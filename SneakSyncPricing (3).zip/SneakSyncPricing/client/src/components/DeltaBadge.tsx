import { ArrowUp, ArrowDown, Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface DeltaBadgeProps {
  delta: number;
  isProtected?: boolean;
  testId?: string;
}

export function DeltaBadge({ delta, isProtected = false, testId }: DeltaBadgeProps) {
  if (isProtected) {
    return (
      <Badge variant="outline" className="font-mono gap-1" data-testid={testId}>
        <Shield className="h-3 w-3" />
        0.0%
      </Badge>
    );
  }

  const isPositive = delta > 0;
  const textColor = isPositive ? "text-success" : "text-info";

  return (
    <Badge
      variant="secondary"
      className={`font-mono gap-1 ${textColor}`}
      data-testid={testId}
    >
      {isPositive ? (
        <ArrowUp className="h-3 w-3" />
      ) : (
        <ArrowDown className="h-3 w-3" />
      )}
      {isPositive ? "+" : ""}
      {delta.toFixed(1)}%
    </Badge>
  );
}

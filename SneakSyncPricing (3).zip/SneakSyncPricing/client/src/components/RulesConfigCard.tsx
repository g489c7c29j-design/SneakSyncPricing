import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useState } from "react";

interface RulesConfig {
  tolerance: number;
  minMargin: number;
  rounding: string;
  dailyCap: number;
  cooldown: number;
  autoUpdateEnabled: boolean;
}

interface RulesConfigCardProps {
  initialConfig?: Partial<RulesConfig>;
  onSave?: (config: RulesConfig) => void;
  testId?: string;
}

export function RulesConfigCard({ initialConfig, onSave, testId }: RulesConfigCardProps) {
  const [config, setConfig] = useState<RulesConfig>({
    tolerance: initialConfig?.tolerance ?? 5,
    minMargin: initialConfig?.minMargin ?? 15,
    rounding: initialConfig?.rounding ?? ".99",
    dailyCap: initialConfig?.dailyCap ?? 10,
    cooldown: initialConfig?.cooldown ?? 120,
    autoUpdateEnabled: initialConfig?.autoUpdateEnabled ?? true,
  });

  const handleSave = () => {
    onSave?.(config);
    console.log('Rules saved:', config);
  };

  return (
    <Card data-testid={testId}>
      <CardHeader>
        <CardTitle>Pricing Rules & Guardrails</CardTitle>
        <CardDescription>
          Configure automatic price update behavior and safety limits
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Label htmlFor="auto-update">Enable Auto-Updates</Label>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  Automatically update prices within tolerance limits
                </TooltipContent>
              </Tooltip>
            </div>
            <Switch
              id="auto-update"
              checked={config.autoUpdateEnabled}
              onCheckedChange={(checked) =>
                setConfig({ ...config, autoUpdateEnabled: checked })
              }
              data-testid={`${testId}-auto-update`}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="tolerance">Tolerance (%)</Label>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Auto-update if change is within ±{config.tolerance}%
                  </TooltipContent>
                </Tooltip>
              </div>
              <Input
                id="tolerance"
                type="number"
                value={config.tolerance}
                onChange={(e) =>
                  setConfig({ ...config, tolerance: Number(e.target.value) })
                }
                data-testid={`${testId}-tolerance`}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="margin">Min Margin (%)</Label>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Never price below cost × (1 + {config.minMargin}%)
                  </TooltipContent>
                </Tooltip>
              </div>
              <Input
                id="margin"
                type="number"
                value={config.minMargin}
                onChange={(e) =>
                  setConfig({ ...config, minMargin: Number(e.target.value) })
                }
                data-testid={`${testId}-margin`}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rounding">Price Rounding</Label>
              <Select
                value={config.rounding}
                onValueChange={(value) =>
                  setConfig({ ...config, rounding: value })
                }
              >
                <SelectTrigger id="rounding" data-testid={`${testId}-rounding`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value=".99">.99</SelectItem>
                  <SelectItem value=".95">.95</SelectItem>
                  <SelectItem value=".00">.00</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="daily-cap">Daily Cap (%)</Label>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Maximum price movement per day
                  </TooltipContent>
                </Tooltip>
              </div>
              <Input
                id="daily-cap"
                type="number"
                value={config.dailyCap}
                onChange={(e) =>
                  setConfig({ ...config, dailyCap: Number(e.target.value) })
                }
                data-testid={`${testId}-daily-cap`}
              />
            </div>

            <div className="space-y-2 col-span-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="cooldown">Cooldown (minutes)</Label>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Wait time between auto-updates for the same product
                  </TooltipContent>
                </Tooltip>
              </div>
              <Input
                id="cooldown"
                type="number"
                value={config.cooldown}
                onChange={(e) =>
                  setConfig({ ...config, cooldown: Number(e.target.value) })
                }
                data-testid={`${testId}-cooldown`}
              />
            </div>
          </div>
        </div>

        <div className="pt-4 border-t">
          <h4 className="font-semibold mb-3 text-sm">Example Calculation</h4>
          <div className="p-4 bg-muted rounded-md space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cost Basis:</span>
              <span className="font-mono">$100.00</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Min Price (15% margin):</span>
              <span className="font-mono">$115.00</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Market Baseline:</span>
              <span className="font-mono">$129.00</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rounded Price:</span>
              <span className="font-mono font-bold">$128.99</span>
            </div>
          </div>
        </div>

        <Button onClick={handleSave} className="w-full" data-testid={`${testId}-save`}>
          Save Rules
        </Button>
      </CardContent>
    </Card>
  );
}

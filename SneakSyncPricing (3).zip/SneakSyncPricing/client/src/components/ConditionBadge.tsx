import { Badge } from "@/components/ui/badge";

interface ConditionBadgeProps {
  condition: "new" | "used" | "pre-owned" | string;
  testId?: string;
}

export function ConditionBadge({ condition, testId }: ConditionBadgeProps) {
  const config: Record<string, { label: string; className: string }> = {
    new: {
      label: "New",
      className: "bg-success/10 text-success border-success/20",
    },
    used: {
      label: "Used",
      className: "bg-warning/10 text-warning border-warning/20",
    },
    "pre-owned": {
      label: "Pre-Owned",
      className: "bg-destructive/10 text-destructive border-destructive/20",
    },
  };

  const { label, className } = config[condition] || { 
    label: condition || "Unknown", 
    className: "bg-muted text-muted-foreground border-muted" 
  };

  return (
    <Badge variant="outline" className={className} data-testid={testId}>
      {label}
    </Badge>
  );
}

import { Badge } from "@/components/ui/badge";

type DataSource = "ebay" | "stockx" | "goat" | "csv" | "marketplace" | "kickscrew" | "stadiumgoods" | "flightclub" | "shopify";

interface SourceIndicatorProps {
  source: DataSource | string;
  count?: number;
  testId?: string;
}

const sourceConfig: Record<string, { label: string; color: string }> = {
  ebay: { label: "eBay", color: "bg-info/10 text-info" },
  stockx: { label: "StockX", color: "bg-success/10 text-success" },
  goat: { label: "GOAT", color: "bg-warning/10 text-warning" },
  csv: { label: "CSV", color: "bg-muted text-muted-foreground" },
  marketplace: { label: "Marketplace", color: "bg-primary/10 text-primary" },
  kickscrew: { label: "KicksCrew", color: "bg-muted text-muted-foreground" },
  stadiumgoods: { label: "Stadium Goods", color: "bg-muted text-muted-foreground" },
  flightclub: { label: "Flight Club", color: "bg-muted text-muted-foreground" },
  shopify: { label: "Shopify", color: "bg-muted text-muted-foreground" },
};

export function SourceIndicator({ source, count, testId }: SourceIndicatorProps) {
  const config = sourceConfig[source] || { label: source, color: "bg-muted text-muted-foreground" };

  return (
    <Badge variant="secondary" className={`${config.color} gap-1`} data-testid={testId}>
      {config.label}
      {count !== undefined && <span className="font-mono">({count})</span>}
    </Badge>
  );
}

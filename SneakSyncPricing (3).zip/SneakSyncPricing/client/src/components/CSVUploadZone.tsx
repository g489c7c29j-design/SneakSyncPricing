import { Upload, FileText, X } from "lucide-react";
import { useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface CSVUploadZoneProps {
  onFileSelect?: (file: File) => void;
  testId?: string;
}

export function CSVUploadZone({ onFileSelect, testId }: CSVUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith('.csv')) {
      setSelectedFile(file);
      onFileSelect?.(file);
    }
  }, [onFileSelect]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      onFileSelect?.(file);
    }
  }, [onFileSelect]);

  const handleClear = useCallback(() => {
    setSelectedFile(null);
  }, []);

  return (
    <Card
      className={`p-8 border-2 border-dashed transition-colors ${
        isDragging ? "border-primary bg-primary/5" : "border-border"
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      data-testid={testId}
    >
      {selectedFile ? (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FileText className="h-8 w-8 text-success" />
            <div>
              <p className="font-medium" data-testid={`${testId}-filename`}>
                {selectedFile.name}
              </p>
              <p className="text-sm text-muted-foreground">
                {(selectedFile.size / 1024).toFixed(1)} KB
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClear}
            data-testid={`${testId}-clear`}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      ) : (
        <label className="flex flex-col items-center gap-4 cursor-pointer">
          <Upload className="h-12 w-12 text-muted-foreground" />
          <div className="text-center">
            <p className="font-medium">Drop CSV or click to browse</p>
            <p className="text-sm text-muted-foreground mt-1">
              Expected columns: source, sku, style_code, price, currency, fees, shipping, date
            </p>
          </div>
          <input
            type="file"
            accept=".csv"
            className="hidden"
            onChange={handleFileInput}
            data-testid={`${testId}-input`}
          />
        </label>
      )}
    </Card>
  );
}

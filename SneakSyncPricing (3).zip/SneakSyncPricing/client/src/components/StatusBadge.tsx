import { Badge } from "@/components/ui/badge";

type StatusType = "auto-updated" | "pending" | "manual" | "protected";

interface StatusBadgeProps {
  status: StatusType;
  testId?: string;
}

const statusConfig = {
  "auto-updated": {
    label: "Auto-updated",
    className: "bg-success/10 text-success hover:bg-success/20",
  },
  pending: {
    label: "Pending",
    className: "bg-warning/10 text-warning hover:bg-warning/20",
  },
  manual: {
    label: "Manual",
    className: "bg-muted text-muted-foreground",
  },
  protected: {
    label: "Protected",
    className: "border-primary text-primary bg-transparent",
  },
};

export function StatusBadge({ status, testId }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <Badge
      variant={status === "protected" ? "outline" : "secondary"}
      className={config.className}
      data-testid={testId}
    >
      {config.label}
    </Badge>
  );
}

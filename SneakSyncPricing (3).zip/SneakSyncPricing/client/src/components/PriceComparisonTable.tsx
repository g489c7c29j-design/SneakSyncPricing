import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Check, X, ChevronDown, ChevronUp, ExternalLink } from "lucide-react";
import { DeltaBadge } from "./DeltaBadge";
import { StatusBadge } from "./StatusBadge";
import { SourceIndicator } from "./SourceIndicator";
import { ConditionBadge } from "./ConditionBadge";
import { EditProductDialog } from "./EditProductDialog";
import { useState, Fragment } from "react";

export interface PriceRow {
  id: string;
  sku: string;
  productName: string;
  condition: "new" | "used" | "pre-owned";
  currentPrice: number;
  suggestedPrice: number;
  delta: number;
  status: "auto-updated" | "pending" | "manual" | "protected";
  sources: { source: "ebay" | "stockx" | "goat" | "csv"; count: number }[];
  thumbnail?: string;
  compData?: { source: string; price: number; date: string; size?: string | null; productUrl?: string | null }[];
  // Full product details for editing
  styleCode?: string;
  size?: string | null;
  costBasis?: number;
  imageUrl?: string | null;
  isProtected?: boolean;
  conditionType?: string;
  conditionScore?: number | null;
  conditionNotes?: string | null;
}

interface PriceComparisonTableProps {
  data: PriceRow[];
  onApprove?: (id: string) => void;
  onReject?: (id: string) => void;
  onEdit?: boolean;
  testId?: string;
}

export function PriceComparisonTable({
  data,
  onApprove,
  onReject,
  testId,
}: PriceComparisonTableProps) {
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  return (
    <div className="border rounded-md overflow-x-auto" data-testid={testId}>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12"></TableHead>
            <TableHead className="hidden md:table-cell">SKU</TableHead>
            <TableHead>Product</TableHead>
            <TableHead className="text-right hidden sm:table-cell">Current</TableHead>
            <TableHead className="text-right">Suggested</TableHead>
            <TableHead className="hidden sm:table-cell">Delta</TableHead>
            <TableHead className="hidden lg:table-cell">Status</TableHead>
            <TableHead className="hidden lg:table-cell">Sources</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((row) => (
            <Fragment key={row.id}>
              <TableRow
                className="hover-elevate cursor-pointer"
                onClick={() =>
                  setExpandedRow(expandedRow === row.id ? null : row.id)
                }
                data-testid={`${testId}-row-${row.id}`}
              >
                <TableCell>
                  {expandedRow === row.id ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </TableCell>
                <TableCell className="font-mono text-sm font-medium hidden md:table-cell">
                  {row.sku}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2 md:gap-3">
                    {row.thumbnail && (
                      <img
                        src={row.thumbnail}
                        alt={row.productName}
                        className="h-8 w-8 md:h-10 md:w-10 rounded border object-cover flex-shrink-0"
                      />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-sm md:text-base line-clamp-2">{row.productName}</span>
                        <ConditionBadge condition={row.condition} />
                        {row.conditionType === "USED" && row.conditionScore && (
                          <span className="text-xs text-muted-foreground font-mono">
                            Score: {row.conditionScore}/10
                          </span>
                        )}
                      </div>
                      <span className="md:hidden block text-xs text-muted-foreground font-mono mt-0.5">{row.sku}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-right font-mono font-bold text-sm md:text-base hidden sm:table-cell">
                  ${row.currentPrice.toFixed(2)}
                </TableCell>
                <TableCell className="text-right font-mono font-bold text-sm md:text-base">
                  <div className="flex flex-col items-end gap-0.5">
                    <span>${row.suggestedPrice.toFixed(2)}</span>
                    <span className="sm:hidden text-xs text-muted-foreground font-normal">
                      from ${row.currentPrice.toFixed(2)}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <DeltaBadge
                    delta={row.delta}
                    isProtected={row.status === "protected"}
                    testId={`${testId}-delta-${row.id}`}
                  />
                </TableCell>
                <TableCell className="hidden lg:table-cell">
                  <StatusBadge
                    status={row.status}
                    testId={`${testId}-status-${row.id}`}
                  />
                </TableCell>
                <TableCell className="hidden lg:table-cell">
                  <div className="flex gap-1 flex-wrap">
                    {row.sources.map((source) => (
                      <SourceIndicator
                        key={source.source}
                        source={source.source}
                        count={source.count}
                      />
                    ))}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex gap-1 justify-end" onClick={(e) => e.stopPropagation()}>
                    <EditProductDialog
                      product={{
                        sku: row.sku,
                        productName: row.productName,
                        condition: row.condition,
                        currentPrice: row.currentPrice,
                        id: row.id,
                      }}
                      fullProduct={
                        row.styleCode
                          ? {
                              styleCode: row.styleCode,
                              size: row.size ?? null,
                              costBasis: row.costBasis ?? 0,
                              imageUrl: row.imageUrl ?? null,
                              conditionType: row.conditionType,
                              conditionScore: row.conditionScore,
                              conditionNotes: row.conditionNotes,
                            }
                          : undefined
                      }
                    />
                    {row.status === "pending" && (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            onApprove?.(row.id);
                          }}
                          data-testid={`${testId}-approve-${row.id}`}
                        >
                          <Check className="h-4 w-4 text-success" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            onReject?.(row.id);
                          }}
                          data-testid={`${testId}-reject-${row.id}`}
                        >
                          <X className="h-4 w-4 text-destructive" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
              {expandedRow === row.id && row.compData && (
                <TableRow>
                  <TableCell colSpan={9} className="bg-muted/30 p-6">
                    <h4 className="font-semibold mb-3">Comparable Data</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {row.compData.map((comp, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-background rounded border"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{comp.source}</p>
                              {comp.size && (
                                <p className="text-xs text-muted-foreground">
                                  Size {comp.size}
                                </p>
                              )}
                            </div>
                            <p className="font-mono font-bold">
                              ${comp.price.toFixed(2)}
                            </p>
                          </div>
                          <div className="flex justify-between items-center gap-2">
                            <p className="text-xs text-muted-foreground">
                              {comp.date}
                            </p>
                            {comp.productUrl && (
                              <a
                                href={comp.productUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="text-xs text-primary hover:underline flex items-center gap-1"
                                data-testid={`${testId}-comp-link-${idx}`}
                              >
                                View
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </Fragment>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

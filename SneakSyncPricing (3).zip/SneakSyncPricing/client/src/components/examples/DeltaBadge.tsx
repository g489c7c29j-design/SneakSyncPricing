import { DeltaBadge } from '../DeltaBadge'

export default function DeltaBadgeExample() {
  return (
    <div className="flex gap-4 p-4 flex-wrap">
      <DeltaBadge delta={5.2} testId="delta-positive" />
      <DeltaBadge delta={-3.1} testId="delta-negative" />
      <DeltaBadge delta={0} isProtected testId="delta-protected" />
    </div>
  )
}

import { StatsCard } from '../StatsCard'

export default function StatsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      <StatsCard
        label="Auto-updates Today"
        value={42}
        trend={{ direction: "up", value: "+12%" }}
        testId="stat-auto-updates"
      />
      <StatsCard
        label="Pending Approvals"
        value={8}
        testId="stat-pending"
      />
      <StatsCard
        label="Avg. Delta %"
        value="3.2%"
        trend={{ direction: "down", value: "-0.5%" }}
        testId="stat-delta"
      />
      <StatsCard
        label="Margin Protected"
        value="94%"
        trend={{ direction: "up", value: "+2%" }}
        testId="stat-margin"
      />
    </div>
  )
}

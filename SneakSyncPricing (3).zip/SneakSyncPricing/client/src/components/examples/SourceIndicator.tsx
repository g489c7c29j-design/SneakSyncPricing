import { SourceIndicator } from '../SourceIndicator'

export default function SourceIndicatorExample() {
  return (
    <div className="flex gap-2 p-4 flex-wrap">
      <SourceIndicator source="ebay" count={12} testId="source-ebay" />
      <SourceIndicator source="stockx" count={8} testId="source-stockx" />
      <SourceIndicator source="goat" count={5} testId="source-goat" />
      <SourceIndicator source="csv" testId="source-csv" />
    </div>
  )
}

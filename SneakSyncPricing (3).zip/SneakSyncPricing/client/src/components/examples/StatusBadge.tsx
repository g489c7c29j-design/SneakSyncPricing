import { StatusBadge } from '../StatusBadge'

export default function StatusBadgeExample() {
  return (
    <div className="flex gap-2 p-4 flex-wrap">
      <StatusBadge status="auto-updated" testId="status-auto" />
      <StatusBadge status="pending" testId="status-pending" />
      <StatusBadge status="manual" testId="status-manual" />
      <StatusBadge status="protected" testId="status-protected" />
    </div>
  )
}

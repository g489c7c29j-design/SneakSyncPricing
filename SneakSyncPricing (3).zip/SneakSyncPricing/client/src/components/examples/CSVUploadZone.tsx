import { CSVUploadZone } from '../CSVUploadZone'

export default function CSVUploadZoneExample() {
  return (
    <div className="p-4">
      <CSVUploadZone
        onFileSelect={(file) => console.log('File selected:', file.name)}
        testId="csv-upload"
      />
    </div>
  )
}

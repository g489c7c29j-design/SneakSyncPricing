import { RulesConfigCard } from '../RulesConfigCard'

export default function RulesConfigCardExample() {
  return (
    <div className="p-4 max-w-2xl">
      <RulesConfigCard
        onSave={(config) => console.log('Saved config:', config)}
        testId="rules-config"
      />
    </div>
  )
}

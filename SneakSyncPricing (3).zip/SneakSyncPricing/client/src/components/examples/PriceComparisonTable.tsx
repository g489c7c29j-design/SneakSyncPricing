import { PriceComparisonTable, type PriceRow } from '../PriceComparisonTable'

const mockData: PriceRow[] = [
  {
    id: "1",
    sku: "CZ0790-110",
    productName: "Air Jordan 1 Retro High OG",
    currentPrice: 249.99,
    suggestedPrice: 262.49,
    delta: 5.0,
    status: "pending",
    sources: [
      { source: "ebay", count: 12 },
      { source: "stockx", count: 8 },
    ],
    compData: [
      { source: "eBay Sold", price: 265.00, date: "2025-10-20" },
      { source: "StockX", price: 260.00, date: "2025-10-19" },
      { source: "GOAT", price: 262.00, date: "2025-10-18" },
    ],
  },
  {
    id: "2",
    sku: "DD1391-100",
    productName: "Nike Dunk Low Panda",
    currentPrice: 129.99,
    suggestedPrice: 126.74,
    delta: -2.5,
    status: "auto-updated",
    sources: [{ source: "ebay", count: 15 }],
  },
  {
    id: "3",
    sku: "FD0774-600",
    productName: "Air Jordan 4 Retro Craft",
    currentPrice: 189.99,
    suggestedPrice: 189.99,
    delta: 0,
    status: "protected",
    sources: [{ source: "stockx", count: 5 }],
  },
];

export default function PriceComparisonTableExample() {
  return (
    <div className="p-4">
      <PriceComparisonTable
        data={mockData}
        onApprove={(id) => console.log('Approved:', id)}
        onReject={(id) => console.log('Rejected:', id)}
        testId="price-table"
      />
    </div>
  )
}
